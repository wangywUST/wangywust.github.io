---
layout: homepage
---

## About Me

I am currently an Applied Scientist at [Amazon Inc.](https://www.amazon.science/). I received my Ph.D. in Computer Science at [National University of Singapore](https://nus.edu.sg/), where I was fortunate to be advised by [Prof. Bryan Hooi](http://bhooi.github.io/). Prior to this, I obtained my Master of Philosophy (MPhil) degree from [The Hong Kong University of Science and Technology](https://hkust.edu.hk/) and Bachelor degree from [Southeast University](https://www.seu.edu.cn/english/_t1875/main.htm).

My work at [Amazon Inc.](https://www.amazon.science/) detect and block the fraud sellers at an early stage to prevent the customers from bearing the losses of purchasing fake products from fraud sellers.
I design and implement the fraud seller detection pipelines empowered the cutting-edge graph neural network and natural language processing algorithms.

My research interests include **natural language understanding**, **graph neural networks**, **computer vision**, and **data mining**.
My recent research is focused on **reliable language models** and **scalable graph neural networks**.

<!--
<strong style="color:#e74d3c; font-weight:600">I am looking for a postdoc or research scientist position in the US and EU. I would appreciate a ping if you see a job I might fit.</strong>
-->

<!-- ## News

<ul>
<li><strong>[Feb. 2023]</strong> Two papers about <a href="./#publications">continual learning</a> are accepted to <a href="http://cvpr2023.thecvf.com/">CVPR 2023</a>.</li>
  <li><strong>[Feb. 2023]</strong> I will serve as an area chair of <a href="https://www.auai.org/uai2023/">UAI 2023</a>.</li>
  <li><strong>[Dec. 2022]</strong> <a href="https://www.bmvc2023.org">BMVC 2023</a> will be held in Aberdeen, UK, and I will serve as the website chair.</li>
  <li><strong>[Nov. 2022]</strong> Our paper about <a href="https://pure.mpg.de/rest/items/item_3478882_1/component/file_3478883/content">class-incremental learning</a> is accepted to <a href="https://aaai.org/Conferences/AAAI-23/">AAAI 2023</a>.</li>
  <li><strong>[Oct. 2022]</strong> I am recognized as a top reviewer for <a href="https://neurips.cc/Conferences/2022/ProgramCommittee">NeurIPS 2022</a>.</li>
  
<li> <a href="javascript:toggle_vis('newsmore')">Show more</a> </li>
<div id="newsmore" style="display:none"> 
  <li><strong>[Aug. 2022]</strong> I will serve as an area chair of <a href="https://aistats.org/aistats2023/">AISTATS 2023</a>.</li>
  <li><strong>[Jun. 2022]</strong> I will serve as a student mentor of <a href="https://sites.google.com/view/cvpr-academy/">the CVPR Academy</a> at <a href="http://cvpr2022.thecvf.com/">CVPR 2022</a>.</li>
  <li><strong>[Jun. 2022]</strong> I will serve as a website chair of <a href="https://bmvc2022.org/people/organisers/">BMVC 2022</a>, along with <a href="https://yashbhalgat.github.io/">Yash Bhalgat</a>.</li>
  <li><strong>[Sep. 2021]</strong> Our paper about <a href="https://openreview.net/pdf?id=BfPzZSype5M">class-incremental learning</a> is accepted to <a href="https://neurips.cc/Conferences/2021">NeurIPS 2021</a>.</li>
  <li><strong>[Mar. 2021]</strong> Our paper about <a href="https://arxiv.org/pdf/2010.05063.pdf">class-incremental learning</a> is accepted to <a href="http://cvpr2021.thecvf.com/">CVPR 2021</a>.</li>
  <li><strong>[Jul. 2020]</strong> Our paper about <a href="https://link.springer.com/content/pdf/10.1007%2F978-3-030-58517-4_24.pdf">few-shot learning</a> is accepted to <a href="https://eccv2020.eu/">ECCV 2020</a>.</li>
  <li><strong>[Feb. 2020]</strong> Our paper about <a href="https://arxiv.org/pdf/2002.10211.pdf">class-incremental learning</a> is accepted to <a href="http://cvpr2020.thecvf.com/">CVPR 2020</a>.</li>
  <li><strong>[Feb. 2020]</strong> We will host the <a href="https://www.acmmmasia.org/2020/committee.html">ACM Multimedia Asia 2020</a> conference in Singapore!</li>
  <li><strong>[Sep. 2019]</strong> Our paper about <a href="https://papers.nips.cc/paper/2019/file/bf25356fd2a6e038f1a3a59c26687e80-Paper.pdf">few-shot learning</a> is accepted to <a href="https://nips.cc/Conferences/2019">NeurIPS 2019</a>.</li>
  <li><strong>[Mar. 2019]</strong> Our paper about <a href="https://openaccess.thecvf.com/content_CVPR_2019/papers/Sun_Meta-Transfer_Learning_for_Few-Shot_Learning_CVPR_2019_paper.pdf">few-shot learning</a> is accepted to <a href="http://cvpr2019.thecvf.com/">CVPR 2019</a>.</li>
</div>

</ul> -->

{% include_relative _includes/publications.md %}

## Teaching
- Teaching Assistant, [Knowledge Discovery and Data Mining](https://nusmods.com/modules/CS5228/knowledge-discovery-and-data-mining) at [National University of Singapore](https://nus.edu.sg/), 2020 and 2021
- Teaching Assistant, [Big Data Systems for Data Science](https://nusmods.com/modules/CS5228/knowledge-discovery-and-data-mining) at [National University of Singapore](https://nus.edu.sg/), 2021
- Teaching Assistant, [Programming Methodology](https://nusmods.com/modules/CS5228/knowledge-discovery-and-data-mining) at [National University of Singapore](https://nus.edu.sg/), 2021
- Teaching Assistant, [Parallel Computing ](https://nusmods.com/modules/CS3210/parallel-computing) at [National University of Singapore](https://nus.edu.sg/), 2020
- Teaching Assistant, [Signal Processing and Communications](https://nusmods.com/modules/CS5228/knowledge-discovery-and-data-mining  ) at [The Hong Kong University of Science and Technology](https://hkust.edu.hk/), 2018

{% include_relative _includes/services.md %}

## Contact
**Address:** [501 Fairview Ave N, Seattle 98109, WA](https://goo.gl/maps/3EpPHNd1Q5zvKS8b7)
<br>
**Office Location:** Amazon - Amelia (Urban Union) Floor 9 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; **Phone:** (425) 525-5851
